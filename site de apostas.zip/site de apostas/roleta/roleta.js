// Seleciona todos os itens do menu
var MenuItem = document.querySelectorAll('.item-menu');

// Define uma função para colorir os botões do menu
function selectlink() {
    // Remove a classe 'ativo' de todos os itens do menu
    MenuItem.forEach((item) =>
        item.classList.remove('ativo')
    );
    // Adiciona a classe 'ativo' ao item de menu clicado
    this.classList.add('ativo');
}

// Adiciona um ouvinte de evento de clique a cada item do menu
MenuItem.forEach((item) =>
    item.addEventListener('click', selectlink)
);

// Seleciona o botão de expansão do menu
var BtnExp = document.querySelector('#btn-exp');
// Seleciona o menu lateral
var menuSide = document.querySelector('.menu-lateral');

// Adiciona um ouvinte de evento de clique ao botão de expansão
BtnExp.addEventListener('click', function () {
    // Alternar a classe 'expandir' no menu lateral
    menuSide.classList.toggle('expandir');
});
